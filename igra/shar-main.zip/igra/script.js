// Interaction Instructions:
// 1. Click and drag to rotate the scene.
// 2. Use your mouse/trackpad scroll to zoom in and out.